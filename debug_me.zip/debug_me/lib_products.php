<?php

class Products {
    public $name;
    public $description;
    public $productId;

    public function __construct($id = 0, $infoArr = array()) {
        if ($id > 0 && count($infoArr)) {
            $this->name = $infoArr['name'];
            $this->description = $infoArr['descriptoin'];
            $this->productId = $id;
        }
    }

    /**
     * @static
     */
    public static function loadAllProducts() {
        $arr = getProducts();
        $prods = array();

        foreach ($arr as $id => $info) {
            $prods[$id] = new Products($id, $info);
        }

        return $prods;
    }

    /**
     * Load details of order
     *
     * This function should be giving us all the information about the order:
     * The customer's name and address, the products that were ordered (descriptions too) and the order totals.
     * See products.php to see what is expected to be shown
     *
     * @param int $order_id Unique identifier for the order
     * @return string[] $cur_order Details of the order
     *
     */
    public function loadOrderDetails($order_id) {
        $orders = getOrderInfo();
        $products = self::loadAllProducts();
        $customer = getCustomerInfo();
        $address = getAddresses();

        return $cur_order;
    }
}